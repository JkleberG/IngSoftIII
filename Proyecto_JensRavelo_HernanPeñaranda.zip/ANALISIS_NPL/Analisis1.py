import tkinter as tk
from tkinter import messagebox
from googletrans import Translator
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from PIL import Image, ImageTk
from tkinter import PhotoImage
# Inicializar VADER
analyzer = SentimentIntensityAnalyzer()

class MainWindow:
    def __init__(self, master):
        self.master = master
        self.master.title("Análisis Emocional con NLP")
        self.master.geometry('700x500+450+100')
        self.master.resizable(width=False, height=False)
        self.master.iconbitmap('IMG/procesamiento-natural-del-lenguaje.ico')
        

        # Configuración de tamaño y posición de la ventana
        ancho_ventana = 600
        alto_ventana = 500
        x_pos = (self.master.winfo_screenwidth() - ancho_ventana) // 2
        y_pos = (self.master.winfo_screenheight() - alto_ventana) // 2
        self.master.geometry(f"{ancho_ventana}x{alto_ventana}+{x_pos}+{y_pos}")
        self.master.configure(bg="#F0F0F0")

        # Etiqueta de título
        etiqueta_titulo = tk.Label(self.master, text="Análisis Emocional con NLP", 
                                   bg="#F0F0F0", font=("Arial", 18, "bold"))
        etiqueta_titulo.pack(pady=20)

        # Cuadro de texto
        self.entrada_texto = tk.Text(self.master, width=40, height=5, font=("Arial", 14), 
                                     wrap="word", borderwidth=2, relief=tk.GROOVE)
        self.entrada_texto.pack(pady=10)

        # Frame para botones "Analizar" y "Vaciar"
        frame_botones = tk.Frame(self.master, bg="#F0F0F0")
        frame_botones.pack(pady=10)

        # Botón de analizar
        boton_analizar = tk.Button(frame_botones, text="Analizar", 
                                   command=self.interpretar_texto, width=12, height=2, 
                                   bg="#5CB85C", fg="white", 
                                   relief=tk.GROOVE, font=("Arial", 12))
        boton_analizar.pack(side="left", padx=5)

        # Botón de vaciar (oculto inicialmente)
        self.boton_vaciar = tk.Button(frame_botones, text="Vaciar", command=self.vaciar_texto, width=12, 
                                      height=2, bg="#FF6347", 
                                      fg="white", relief=tk.GROOVE, font=("Arial", 12))
        self.boton_vaciar.pack_forget()  # Inicialmente oculto

        # Etiqueta para mostrar el resultado
        self.etiqueta_resultado = tk.Label(self.master, text="", bg="#F0F0F0", font=("Arial", 16, "bold"))
        self.etiqueta_resultado.pack(pady=10)

        # Imagen del botón de ayuda
        self.imagen_ayuda = Image.open('./IMG/ayuda.png')  # Asegúrate de que la extensión sea correcta
        self.imagen_ayuda = self.imagen_ayuda.resize((30, 30), Image.LANCZOS)  # Cambiar ANTIALIAS por LANCZOS
        self.icono_ayuda = ImageTk.PhotoImage(self.imagen_ayuda)

        # Botón de ayuda
        boton_ayuda = tk.Button(self.master, image=self.icono_ayuda, command=self.mostrar_ayuda, bg="#F0F0F0", relief=tk.GROOVE)
        boton_ayuda.pack(pady=10)

    def traducir_a_ingles(self, texto):
        translator = Translator()
        texto_traducido = translator.translate(texto, dest='en')
        return texto_traducido.text

    def analyze_sentiment(self, text):
        # Análisis de sentimiento usando VADER
        sentiment_scores = analyzer.polarity_scores(text)
        compound_score = sentiment_scores['compound']

        if compound_score > 0:
            return "Positivo"
        elif compound_score < 0:
            return "Negativo"
        else:
            return "Neutral"

    def interpretar_texto(self):
        texto_ingresado = self.entrada_texto.get("1.0", tk.END).strip()

        if not texto_ingresado:
            messagebox.showerror("Error", "Campo vacío. Por favor, ingresa texto.")
        else:
            texto_traducido = self.traducir_a_ingles(texto_ingresado)
            resultado_sentimiento = self.analyze_sentiment(texto_traducido)
            self.etiqueta_resultado.config(text=f"\nSentimiento: {resultado_sentimiento}")
            # Mostrar el botón de "Vaciar" al lado del botón "Analizar"
            self.boton_vaciar.pack(side="left", padx=10)

    def vaciar_texto(self):
        # Vaciar el cuadro de texto y ocultar el botón de "Vaciar"
        self.entrada_texto.delete("1.0", tk.END)
        self.etiqueta_resultado.config(text="")
        self.boton_vaciar.pack_forget()  # Ocultar el botón de vaciar

    def mostrar_ayuda(self):
        # Ocultar la ventana principal y abrir la ventana de ayuda
        self.master.withdraw()
        AyudaWindow(self.master)
        
        
        

class AyudaWindow:
    def __init__(self, parent):
        self.ayuda_window = tk.Toplevel(parent)
        self.ayuda_window.title("Análisis Emocional con NLP")
        self.ayuda_window.iconbitmap('./IMG/procesamiento-natural-del-lenguaje.ico')
        ancho_ventana = 600
        alto_ventana = 300
        x_pos = (self.ayuda_window.winfo_screenwidth() - ancho_ventana) // 2
        y_pos = (self.ayuda_window.winfo_screenheight() - alto_ventana) // 2
        self.ayuda_window.geometry(f"{ancho_ventana}x{alto_ventana}+{x_pos}+{y_pos}")
        self.ayuda_window.configure(bg="#F0F0F0")
        
        
        # Titulo Proyecto Ciencia de Datos
        descripcion = tk.Label(
        self.ayuda_window, 
        text=("SISTEMA INTELIGENTE DE PREDICCIÓN TEMPRANA DE PURPURA REUMATOIDEA\n"
        "USANDO PROGRAMACIÓN PARALELA, IMÁGENES DE LA PIEL Y TÉCNICAS DEEP LEARNING\n"
        "COMO APOYO AL DIAGNÓSTICO POR PARTE DE LOS ESPECIALISTAS DE LA SALUD."),
        font=("Arial", 10), 
        fg="black", 
        bg="#F0F0F0", 
        justify="center")
        descripcion.pack(pady=10)
        
        # Botón para volver
        boton_volver =tk.Button(self.ayuda_window,bg="#5CB85C", text="Volver a Inicio", command=self.volver_inicio, width=12, height=2, fg="white", relief=tk.GROOVE, font=("Arial", 12))
        boton_volver.pack(pady=10)

        # etiqueta autores
        autoresLabel1 = tk.Label(
        self.ayuda_window, 
        text=("AUTORES"),
        font=("Arial", 11,'bold'), 
        fg="black", 
        bg="#F0F0F0", 
        justify="center")
        autoresLabel1.pack()

        # Nombres AUTORES
        autoresLabel2 = tk.Label(
        self.ayuda_window, 
        text=("Hernan Jair Peñaranda Misse\nJuan Camilo Arciniegas"),
        font=("Arial", 11), 
        fg="black", 
        bg="#F0F0F0", 
        justify="center")
        autoresLabel2.pack()

    def volver_inicio(self):
        # Cerrar la ventana de ayuda y volver a mostrar la ventana principal
        self.ayuda_window.destroy()
        root.deiconify()

if __name__ == "__main__":
    root = tk.Tk()
    app = MainWindow(root)
    root.mainloop()

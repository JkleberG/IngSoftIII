from googletrans import Translator
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# Inicializar VADER y el traductor
analyzer = SentimentIntensityAnalyzer()

class SentimentAnalysis:
    @staticmethod
    def traducir_a_ingles(texto):
        # Traducción del texto al inglés
        translator = Translator()
        texto_traducido = translator.translate(texto, dest='en')
        return texto_traducido.text

    @staticmethod
    def analyze_sentiment(text):
        # Análisis de sentimiento usando VADER
        sentiment_scores = analyzer.polarity_scores(text)
        compound_score = sentiment_scores['compound']
        
        if compound_score > 0:
            return "Positivo"
        elif compound_score < 0:
            return "Negativo"
        else:
            return "Neutral"
